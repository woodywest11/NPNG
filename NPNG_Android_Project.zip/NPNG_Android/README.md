# NPNG — No Pain No Gain

Starter Android project for the NPNG workout app.

Included:
- NPNG splash/loading screen
- Dark fitness UI with bright green accent
- Home screen
- Start Workout flow
- Beginner full-body workout
- Workout-in-progress screen
- Progress screen
- Bottom navigation
- No external app libraries required

## Build
Open this folder in Android Studio and let Gradle sync, then:
Build > Build APK(s)

The app uses:
- package: com.npng.app
- min Android: API 24
- target Android: API 35
- version: 1.0

## Install
After building, copy the generated APK to the phone and install it with an APK installer.
