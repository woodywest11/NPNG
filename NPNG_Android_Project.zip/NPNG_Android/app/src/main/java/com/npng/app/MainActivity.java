package com.npng.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    int green = Color.rgb(99,255,99);
    int black = Color.rgb(7,16,10);
    int dark = Color.rgb(13,23,16);
    int card = Color.rgb(20,32,25);
    int white = Color.rgb(245,255,245);
    int muted = Color.rgb(145,164,147);

    int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        showSplash();
    }

    TextView tv(String text, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    GradientDrawable bg(int color, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(dp(radius));
        return g;
    }

    Button actionButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(black);
        b.setTextSize(15);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setAllCaps(false);
        b.setBackground(bg(green, 18));
        b.setPadding(dp(18),0,dp(18),0);
        return b;
    }

    void showSplash() {
        FrameLayout f = new FrameLayout(this);
        f.setBackgroundColor(black);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        TextView mark = tv("N", 54, black, true);
        mark.setGravity(Gravity.CENTER);
        mark.setBackground(bg(green, 60));
        box.addView(mark, new LinearLayout.LayoutParams(dp(94),dp(94)));
        TextView name = tv("NO PAIN NO GAIN", 25, white, true);
        name.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1,dp(50));
        np.topMargin = dp(20);
        box.addView(name,np);
        TextView sub = tv("Train hard. Stay consistent. Get stronger.", 13, muted, false);
        sub.setGravity(Gravity.CENTER);
        box.addView(sub,new LinearLayout.LayoutParams(-1,dp(40)));
        f.addView(box,new FrameLayout.LayoutParams(-1,-1));
        setContentView(f);
        new Handler().postDelayed(this::showHome, 1300);
    }

    void baseScreen(String title) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(black);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(18),dp(18),dp(18),dp(12));
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(content);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav = new LinearLayout(this);
        nav.setPadding(dp(8),dp(8),dp(8),dp(8));
        nav.setGravity(Gravity.CENTER);
        nav.setBackgroundColor(dark);
        String[] labels={"HOME","WORKOUT","PROGRESS"};
        for(String s:labels){
            TextView n=tv(s,11,s.equals("HOME")?green:muted,true);
            n.setGravity(Gravity.CENTER);
            nav.addView(n,new LinearLayout.LayoutParams(0,dp(54),1));
            if(s.equals("HOME")) n.setOnClickListener(v->showHome());
            if(s.equals("WORKOUT")) n.setOnClickListener(v->showWorkout());
            if(s.equals("PROGRESS")) n.setOnClickListener(v->showProgress());
        }
        root.addView(nav,new LinearLayout.LayoutParams(-1,dp(70)));
        setContentView(root);
    }

    void showHome() {
        baseScreen("Home");
        LinearLayout header=new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo=tv("N",25,black,true); logo.setGravity(Gravity.CENTER); logo.setBackground(bg(green,40));
        header.addView(logo,new LinearLayout.LayoutParams(dp(52),dp(52)));
        LinearLayout htxt=new LinearLayout(this); htxt.setOrientation(LinearLayout.VERTICAL);
        TextView a=tv("NO PAIN NO GAIN",20,white,true);
        TextView c=tv("Ready to train?",13,muted,false);
        htxt.addView(a,new LinearLayout.LayoutParams(-1,dp(28)));
        htxt.addView(c,new LinearLayout.LayoutParams(-1,dp(22)));
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(0,dp(58),1); hp.leftMargin=dp(12);
        header.addView(htxt,hp);
        content.addView(header);

        TextView hero=tv("BUILD THE\nSTRONGER YOU.",31,white,true);
        hero.setPadding(0,dp(26),0,dp(8));
        content.addView(hero,new LinearLayout.LayoutParams(-1,dp(100)));

        TextView quote=tv("Train hard. Stay consistent. Get stronger.",14,muted,false);
        content.addView(quote,new LinearLayout.LayoutParams(-1,dp(30)));

        Button start=actionButton("START WORKOUT  →");
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(58)); sp.topMargin=dp(16);
        content.addView(start,sp); start.setOnClickListener(v->showWorkout());

        LinearLayout stats=new LinearLayout(this); stats.setPadding(0,dp(18),0,dp(8));
        stats.addView(stat("WORKOUTS","0"),new LinearLayout.LayoutParams(0,dp(90),1));
        stats.addView(stat("STREAK","0 DAYS"),new LinearLayout.LayoutParams(0,dp(90),1));
        stats.addView(stat("MINUTES","0"),new LinearLayout.LayoutParams(0,dp(90),1));
        content.addView(stats);

        TextView p=tv("PROGRESS",18,white,true); p.setPadding(0,dp(12),0,dp(8));
        content.addView(p);
        LinearLayout progress=cardLayout();
        TextView pt=tv("Your progress will appear here after your first workout.",14,muted,false);
        pt.setPadding(dp(16),dp(12),dp(16),dp(12));
        progress.addView(pt,new LinearLayout.LayoutParams(-1,dp(72)));
        content.addView(progress);
    }

    LinearLayout stat(String label,String value){
        LinearLayout l=cardLayout(); l.setGravity(Gravity.CENTER);
        TextView v=tv(value,20,green,true); v.setGravity(Gravity.CENTER);
        TextView t=tv(label,10,muted,true); t.setGravity(Gravity.CENTER);
        l.addView(v,new LinearLayout.LayoutParams(-1,dp(38)));
        l.addView(t,new LinearLayout.LayoutParams(-1,dp(30)));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(88),1); p.leftMargin=dp(3); p.rightMargin=dp(3);
        l.setLayoutParams(p); return l;
    }

    LinearLayout cardLayout(){
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setBackground(bg(card,16)); return l;
    }

    void showWorkout(){
        baseScreen("Workout");
        TextView title=tv("FULL BODY STARTER",24,white,true);
        content.addView(title,new LinearLayout.LayoutParams(-1,dp(48)));
        TextView info=tv("3 exercises • beginner friendly",13,muted,false);
        content.addView(info,new LinearLayout.LayoutParams(-1,dp(32)));
        String[][] ex={{"01","SQUATS","3 sets × 12 reps"},{"02","PUSH-UPS","3 sets × 10 reps"},{"03","PLANK","3 sets × 30 sec"}};
        for(String[] e:ex){
            LinearLayout row=cardLayout(); row.setPadding(dp(14),dp(10),dp(14),dp(10));
            TextView num=tv(e[0],13,green,true); num.setGravity(Gravity.CENTER);
            row.addView(num,new LinearLayout.LayoutParams(dp(45),dp(34)));
            TextView nm=tv(e[1],16,white,true);
            TextView reps=tv(e[2],12,muted,false);
            LinearLayout tx=new LinearLayout(this); tx.setOrientation(LinearLayout.VERTICAL); tx.addView(nm,new LinearLayout.LayoutParams(-1,dp(28))); tx.addView(reps,new LinearLayout.LayoutParams(-1,dp(22)));
            row.addView(tx,new LinearLayout.LayoutParams(0,dp(56),1));
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(78)); rp.topMargin=dp(10); content.addView(row,rp);
        }
        Button begin=actionButton("BEGIN SESSION");
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(58)); bp.topMargin=dp(18); content.addView(begin,bp);
        begin.setOnClickListener(v->runTimer());
    }

    void runTimer(){
        content.removeAllViews();
        TextView t=tv("WORKOUT IN PROGRESS",24,white,true); t.setGravity(Gravity.CENTER);
        content.addView(t,new LinearLayout.LayoutParams(-1,dp(70)));
        TextView exercise=tv("SQUATS",36,green,true); exercise.setGravity(Gravity.CENTER);
        content.addView(exercise,new LinearLayout.LayoutParams(-1,dp(80)));
        TextView timer=tv("00:30",58,white,true); timer.setGravity(Gravity.CENTER);
        content.addView(timer,new LinearLayout.LayoutParams(-1,dp(120)));
        Button next=actionButton("NEXT EXERCISE");
        content.addView(next,new LinearLayout.LayoutParams(-1,dp(58)));
        next.setOnClickListener(v->{ exercise.setText("PUSH-UPS"); timer.setText("00:30"); });
        Button finish=actionButton("FINISH WORKOUT");
        LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-1,dp(58)); fp.topMargin=dp(12); content.addView(finish,fp);
        finish.setOnClickListener(v->showProgress());
    }

    void showProgress(){
        baseScreen("Progress");
        TextView t=tv("YOUR PROGRESS",25,white,true); content.addView(t,new LinearLayout.LayoutParams(-1,dp(54)));
        content.addView(stat("TOTAL WORKOUTS","0"));
        TextView h=tv("KEEP GOING",18,white,true); h.setPadding(0,dp(22),0,dp(8)); content.addView(h);
        TextView m=tv("Complete your first session and NPNG will start tracking your activity.",14,muted,false);
        m.setPadding(dp(16),dp(14),dp(16),dp(14));
        LinearLayout c=cardLayout(); c.addView(m,new LinearLayout.LayoutParams(-1,dp(86))); content.addView(c);
    }
}
